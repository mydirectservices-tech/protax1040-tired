import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import App from './pages/App'
import About from './pages/About'
import Software from './pages/Software'
import Pricing from './pages/Pricing'
import University from './pages/University'
import Resources from './pages/Resources'
import Contact from './pages/Contact'
import Login from './pages/Login'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<App />} />
        <Route path='/about' element={<About />} />
        <Route path='/software' element={<Software />} />
        <Route path='/pricing' element={<Pricing />} />
        <Route path='/university' element={<University />} />
        <Route path='/resources' element={<Resources />} />
        <Route path='/contact' element={<Contact />} />
        <Route path='/login' element={<Login />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
)