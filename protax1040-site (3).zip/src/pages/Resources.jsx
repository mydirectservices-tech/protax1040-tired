export default function Resources() {
  return <div style={{ padding: '2rem' }}><h1>Resources Page - ProTax1040</h1></div>
}