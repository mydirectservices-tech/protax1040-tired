export default function About() {
  return <div style={{ padding: '2rem' }}><h1>About Page - ProTax1040</h1></div>
}