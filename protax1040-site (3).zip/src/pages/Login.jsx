export default function Login() {
  return <div style={{ padding: '2rem' }}><h1>Login Page - ProTax1040</h1></div>
}