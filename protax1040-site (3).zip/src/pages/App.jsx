export default function App() {
  return <div style={{ padding: '2rem' }}><h1>App Page - ProTax1040</h1></div>
}