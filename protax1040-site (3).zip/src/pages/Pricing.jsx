export default function Pricing() {
  return <div style={{ padding: '2rem' }}><h1>Pricing Page - ProTax1040</h1></div>
}